# 模型卡：HandLandmarker（`hand_landmarker.task`）

本文件随发布包分发（`dist/licenses/MODEL-CARD-hand_landmarker.md`），用于登记本项目唯一随包分发的第三方模型。

## 1. 标识与来源

| 项 | 值 |
|---|---|
| 模型 | MediaPipe Hand Landmarker（手部 21 关键点检测） |
| 分发名 | `hand_landmarker.task` |
| 版本/档位 | `float16/1` |
| 上游地址 | https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task |
| 官方模型页 | https://ai.google.dev/edge/mediapipe/solutions/vision/hand_landmarker |
| 许可 | Apache License 2.0（全文随包：`licenses/Apache-2.0.txt`） |
| 文件大小 | 7,819,105 字节 |
| SHA-256 | `FBC2A30080C3C557093B5DDFC334698132EB341044CCEE322CCF8BCF3607CDE1` |
| 本地路径 | `public/models/hand_landmarker.task` → 发布包 `dist/models/hand_landmarker.task` |

校验方法（PowerShell）：

```powershell
(Get-FileHash public\models\hand_landmarker.task -Algorithm SHA256).Hash
```

## 2. 用途与边界

- **用途**：只用于本项目手势六爻体验的本地手部关键点推理，把摄像头画面转成 21 个手部关键点，供手势状态机判定（张开手掌/握拳/捏合/食指）。
- **不改动**：模型权重不重训、不微调、不再分发到第三方。
- **不做**：不做人脸识别、不做身份识别、不做情绪或属性推断、不做任何内容审核用途。

## 3. 输入与输出

- **输入**：摄像头单帧图像，`getUserMedia` 取得后经 `createImageBitmap` 交给 Web Worker。
- **输出**：21 个手部关键点坐标（归一化 x/y/z）与左右手标记。**只在内存中传给同进程的状态机**，不写盘、不上传。
- **运行方式**：`HandLandmarker` 在浏览器 Web Worker 内调用本地 wasm 推理（`public/mediapipe/wasm/`），全流程离线。

## 4. 隐私

- 摄像头帧**不出设备**：帧从 `<video>` 进入 Worker，推理后只回传关键点数组，代码路径中无网络出口。
- 发布包由 `index.html` 的 CSP 强制 `connect-src 'self'`，任何外域请求在网络层被拒绝（含 MediaPipe 上游自带的 odml 使用统计上报器 `https://odml.pa.googleapis.com/v1/log`，实测已被 CSP 阻断）。
- 不采集、不保存、不上传图像与关键点；持久化只写 `localStorage` 内的起卦会话（seed、18 面、六爻爻值、卦象名），不含任何生物特征数据。

## 5. 已知限制（如实登记）

- 模型精度受光照、遮挡、手部距离影响；逆光或手部出画时关键点抖动会增大，此时不落爻（由手势状态机的保持时长与去抖窗口兜底）。
- 只支持单手主导判定；双手同时入画时按置信度取主导手。
- 上游模型为通用手部关键点模型，非为本项目定制，极端角度（手掌完全侧对镜头）识别率下降。
- 上游包 `@mediapipe/tasks-vision@1.2.2` 的 npm 包内不带 LICENSE 文件，本项目的 Apache-2.0 全文以 `licenses/Apache-2.0.txt` 自备随包，不依赖 `node_modules` 残留。
