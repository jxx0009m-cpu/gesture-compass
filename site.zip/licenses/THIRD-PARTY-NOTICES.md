# 第三方组件与素材许可

本项目不复制参考视频里的白话文案、英文译文、判语或素材；卦名/上下卦/文王序与卦辞原文来自公版《周易》（王弼本＋朱熹《周易本义》）人工录入。现代释义为本项目自写，单独成层标注「现代释义」。

| 组件 | 版本 | 许可 | 来源 | 本地路径 |
|---|---|---|---|---|
| three | 0.187.x | MIT | https://github.com/mrdoob/three.js | `node_modules/three` |
| @mediapipe/tasks-vision | 1.2.2 | Apache-2.0 | https://github.com/google-ai-edge/mediapipe | `node_modules/@mediapipe/tasks-vision` |
| HandLandmarker 模型 `hand_landmarker.task` | float16/1 | Apache-2.0（MediaPipe 模型卡） | https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task | `public/models/hand_landmarker.task` |
| @fontsource/noto-serif-sc | 5.3.x | OFL-1.1（`node_modules/@fontsource/noto-serif-sc/package.json` 实测 `license` 字段） | https://github.com/notofonts/noto-cjk | `node_modules/@fontsource/noto-serif-sc` |
| vite | 8.x | MIT | https://github.com/vitejs/vite | `node_modules/vite` |
| vitest | 5.x | MIT | https://github.com/vitest-dev/vitest | `node_modules/vitest` |
| typescript | 6.x | Apache-2.0 | https://github.com/microsoft/TypeScript | `node_modules/typescript` |
| eslint / typescript-eslint | 10.x / 8.x | MIT | https://github.com/eslint/eslint | `node_modules/eslint` |
| @playwright/test | 1.65.x | Apache-2.0 | https://github.com/microsoft/playwright | `node_modules/@playwright/test` |
| tsx | 4.x | MIT | https://github.com/privatenumber/tsx | `node_modules/tsx` |

## 随发布包分发（`dist/licenses/`）

发布包内含许可全文与声明，不依赖 `node_modules` 是否残留：

| 文件 | 内容 | 覆盖对象 | 字节 |
|---|---|---|---|
| `licenses/Apache-2.0.txt` | Apache License 2.0 全文 | `@mediapipe/tasks-vision`、`hand_landmarker.task`、typescript、playwright | 11357 |
| `licenses/OFL-1.1.txt` | SIL Open Font License 1.1 全文 | `@fontsource/noto-serif-sc` 字体文件 | 4314 |
| `licenses/THIRD-PARTY-NOTICES.md` | 本文件副本 | 全部第三方组件 | 见构建产物 |
| `licenses/MODEL-CARD-hand_landmarker.md` | 模型卡：来源、SHA256、用途、输入输出、隐私 | `hand_landmarker.task` | 见构建产物 |

## 模型校验

`public/models/hand_landmarker.task`（7,819,105 字节）

```
SHA-256  FBC2A30080C3C557093B5DDFC334698132EB341044CCEE322CCF8BCF3607CDE1
```

来源：MediaPipe 官方模型库 `mediapipe-models/hand_landmarker/float16/1`，官方模型卡 https://ai.google.dev/edge/mediapipe/solutions/vision/hand_landmarker 。许可 Apache-2.0，全文随包于 `licenses/Apache-2.0.txt`。详见 `licenses/MODEL-CARD-hand_landmarker.md`。

## 许可全文位置

- Apache-2.0 全文：`public/licenses/Apache-2.0.txt`（随包分发，不引用 `node_modules` 路径）
- OFL-1.1 全文：`public/licenses/OFL-1.1.txt`（随包分发）
- MIT 组件：各包内 `node_modules/<pkg>/LICENSE` 为 MIT 标准正文，与本文件表格声明一致；MIT 不强制随二进制分发全文，如需完整 MIT 正文可按包名取用。
- `@mediapipe/tasks-vision` 的 npm 包内**不带 LICENSE 文件**（仅 `package.json` 的 `license` 字段声明 Apache-2.0），因此 Apache-2.0 全文以 `public/licenses/Apache-2.0.txt` 随包提供，不写指向包内的死链。

音频：本期无音频资源（若后续接入，须 CC0 或自产并逐条登记来源、版本、许可）。

## lunar-javascript（出生八字计算）

MIT License

Copyright (c) 2018 6tail

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
